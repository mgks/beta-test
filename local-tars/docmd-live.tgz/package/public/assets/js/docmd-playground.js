/**
 * docmd Playground Plugin Runtime
 * Lightweight client-side code runner with live preview & console interception.
 */

(function () {
  'use strict';

  function formatValue(val) {
    if (val === undefined) return 'undefined';
    if (val === null) return 'null';
    if (typeof val === 'string') return `"${val}"`;
    if (typeof val === 'function') return `[Function: ${val.name || 'anonymous'}]`;
    if (val instanceof Error) return `${val.name}: ${val.message}\n${val.stack || ''}`;
    if (typeof val === 'object') {
      try {
        return JSON.stringify(val, null, 2);
      } catch {
        return Object.prototype.toString.call(val);
      }
    }
    return String(val);
  }

  function getTimeString() {
    const d = new Date();
    return d.toTimeString().split(' ')[0] + '.' + String(d.getMilliseconds()).padStart(3, '0');
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  class PlaygroundInstance {
    constructor(container) {
      this.container = container;
      this.lang = (container.getAttribute('data-lang') || 'js').toLowerCase();
      const template = container.querySelector('.docmd-playground-initial-code');
      const templateCode = template ? (template.content ? template.content.textContent : (template.textContent || template.innerHTML)) : '';
      this.editor = container.querySelector('.docmd-playground-editor');
      this.initialCode = (this.editor && typeof this.editor.defaultValue === 'string' && this.editor.defaultValue.length > 0)
        ? this.editor.defaultValue
        : (templateCode || '').trim();
      this.consoleEl = container.querySelector('.docmd-playground-console');
      this.previewEl = container.querySelector('.docmd-playground-preview');
      this.runBtn = container.querySelector('.docmd-playground-run-btn');
      this.resetBtn = container.querySelector('.docmd-playground-reset-btn');
      this.copyBtn = container.querySelector('.docmd-playground-copy-btn');
      this.clearBtn = container.querySelector('.docmd-playground-clear-btn');
      this.tabButtons = container.querySelectorAll('.docmd-playground-tab');
      this.panels = container.querySelectorAll('.docmd-playground-tab-panel');
      this.viewTabs = container.querySelectorAll('.docmd-playground-view-tab');
      this.hasRun = false;
      this.activeWorker = null;
      this.workerTimeout = null;

      this.init();
    }

    init() {
      if (this.editor && !this.editor.value) {
        this.editor.value = this.initialCode;
      }

      this.defaultTab = (this.container.getAttribute('data-default-tab') || (this.lang === 'html' || this.lang === 'xml' || this.lang === 'svg' ? 'preview' : 'console')).toLowerCase();

      this.bindEditorEvents();
      this.bindActions();
      this.bindTabs();
      this.bindViewTabs();

      // Show empty console hint initially
      this.renderEmptyConsole();

      // Automatically render preview on init if HTML/SVG or default tab is preview so preview tab is never blank
      if (this.lang === 'html' || this.lang === 'xml' || this.lang === 'svg' || this.defaultTab === 'preview') {
        this.renderHtmlPreview(this.editor ? this.editor.value : this.initialCode);
        this.switchTab(this.defaultTab);
      }

      // Auto-run if data-live="true" or data-autorun="true"
      if (this.container.getAttribute('data-live') === 'true' || this.container.getAttribute('data-autorun') === 'true') {
        this.run();
      }
    }

    bindEditorEvents() {
      if (!this.editor) return;

      // Handle Tab key indentation
      this.editor.addEventListener('keydown', (e) => {
        if (e.key === 'Tab') {
          e.preventDefault();
          const start = this.editor.selectionStart;
          const end = this.editor.selectionEnd;
          const val = this.editor.value;
          this.editor.value = val.substring(0, start) + '  ' + val.substring(end);
          this.editor.selectionStart = this.editor.selectionEnd = start + 2;
        }

        // Cmd+Enter or Ctrl+Enter to run
        if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
          e.preventDefault();
          this.run();
        }
      });
    }

    bindActions() {
      if (this.runBtn) {
        this.runBtn.addEventListener('click', () => {
          this.run();
          this.switchView('live');
        });
      }
      if (this.resetBtn) {
        this.resetBtn.addEventListener('click', () => this.reset());
      }
      if (this.copyBtn) {
        this.copyBtn.addEventListener('click', () => this.copy());
      }
      if (this.clearBtn) {
        this.clearBtn.addEventListener('click', () => this.clearConsole());
      }
    }

    bindTabs() {
      this.tabButtons.forEach((btn) => {
        btn.addEventListener('click', () => {
          const targetTab = btn.getAttribute('data-tab');
          this.switchTab(targetTab);
        });
      });
    }

    bindViewTabs() {
      this.viewTabs.forEach((tab) => {
        tab.addEventListener('click', () => {
          const view = tab.getAttribute('data-view');
          this.switchView(view);
        });
      });
    }

    switchView(viewName) {
      this.container.setAttribute('data-active-view', viewName);
      this.viewTabs.forEach((t) => {
        t.classList.toggle('active', t.getAttribute('data-view') === viewName);
      });
      if (viewName === 'live') {
        if (this.lang === 'html' || this.lang === 'xml' || this.lang === 'svg' || this.defaultTab === 'preview') {
          const hasIframe = Boolean(this.previewEl && this.previewEl.querySelector('iframe'));
          if (!hasIframe) {
            this.renderHtmlPreview(this.editor ? this.editor.value : this.initialCode);
          }
        } else if (!this.hasRun) {
          this.run();
        }
      }
    }

    switchTab(tabName) {
      this.tabButtons.forEach((b) => {
        b.classList.toggle('active', b.getAttribute('data-tab') === tabName);
      });
      this.panels.forEach((p) => {
        p.classList.toggle('active', p.getAttribute('data-panel') === tabName);
      });

      // Auto-render preview if switched to preview and preview is currently empty
      if (tabName === 'preview') {
        const hasIframe = Boolean(this.previewEl && this.previewEl.querySelector('iframe'));
        if (!hasIframe) {
          const code = this.editor ? this.editor.value : this.initialCode;
          this.renderHtmlPreview(code);
        }
      }
    }

    renderEmptyConsole() {
      if (!this.consoleEl) return;
      this.consoleEl.innerHTML = '<div class="docmd-pg-log-empty">Console ready. Click "Run" or press ⌘↵ to execute.</div>';
    }

    clearConsole() {
      if (!this.consoleEl) return;
      this.renderEmptyConsole();
    }

    renderErrorNotice(errMsg) {
      if (!this.consoleEl) return;
      const existing = this.consoleEl.querySelector('.docmd-pg-error-notice');
      if (existing) existing.remove();

      const notice = document.createElement('div');
      notice.className = 'docmd-pg-error-notice';
      notice.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0; margin-top:2px;"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <div class="docmd-pg-error-body">
          <div class="docmd-pg-error-title">Playground Execution Warning</div>
          <div class="docmd-pg-error-msg">${escapeHtml(errMsg)}</div>
        </div>
      `;
      this.consoleEl.prepend(notice);
    }

    appendLog(type, content) {
      if (!this.consoleEl) return;
      const emptyNotice = this.consoleEl.querySelector('.docmd-pg-log-empty');
      if (emptyNotice) emptyNotice.remove();

      const row = document.createElement('div');
      row.className = `docmd-pg-log-entry docmd-pg-log-${type}`;

      const time = document.createElement('span');
      time.className = 'docmd-pg-log-time';
      time.textContent = getTimeString();

      const msg = document.createElement('span');
      msg.className = 'docmd-pg-log-content';
      msg.textContent = content;

      row.appendChild(time);
      row.appendChild(msg);
      this.consoleEl.appendChild(row);
      this.consoleEl.scrollTop = this.consoleEl.scrollHeight;
    }

    async run() {
      this.hasRun = true;
      const code = this.editor ? this.editor.value : '';

      // Terminate any currently active worker and timer
      if (this.activeWorker) {
        this.activeWorker.terminate();
        this.activeWorker = null;
      }
      if (this.workerTimeout) {
        clearTimeout(this.workerTimeout);
        this.workerTimeout = null;
      }

      // If language is HTML or markup, render preview
      if (this.lang === 'html' || this.lang === 'xml' || this.lang === 'svg') {
        this.renderHtmlPreview(code);
        this.switchTab('preview');
        return;
      }

      // JavaScript / TypeScript execution
      this.clearConsole();
      this.switchTab('console');

      const customConsole = {
        log: (...args) => this.appendLog('info', args.map(formatValue).join(' ')),
        info: (...args) => this.appendLog('info', args.map(formatValue).join(' ')),
        warn: (...args) => this.appendLog('warn', args.map(formatValue).join(' ')),
        error: (...args) => this.appendLog('error', args.map(formatValue).join(' ')),
        table: (data) => this.appendLog('info', typeof data === 'object' ? JSON.stringify(data, null, 2) : formatValue(data)),
        clear: () => this.clearConsole()
      };

      // Strip simple TS type annotations if written in TS mode
      let cleanJs = code;
      if (this.lang === 'ts' || this.lang === 'typescript') {
        cleanJs = cleanJs
          .replace(/:\s*[A-Z][a-zA-Z0-9<>\[\]|&\s]*/g, '')
          .replace(/as\s+[A-Z][a-zA-Z0-9<>\[\]|&\s]*/g, '');
      }

      // Prepare docmd state snapshot for safe pass-through into sandbox
      const docmdSnapshot = {
        version: window.docmd?.version || '0.10.2',
        variables: (window.docmd?.var?.all && typeof window.docmd.var.all === 'function')
          ? window.docmd.var.all()
          : {}
      };

      // 1. Primary Isolated Execution: Web Worker (Blob URL)
      // Web Workers execute in a completely isolated thread with NO access to window,
      // document, document.cookie, localStorage, sessionStorage, or the parent DOM.
      if (typeof Worker !== 'undefined' && typeof Blob !== 'undefined' && typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {
        try {
          const workerSource = `
            function formatVal(val) {
              if (val === undefined) return 'undefined';
              if (val === null) return 'null';
              if (typeof val === 'string') return '"' + val + '"';
              if (typeof val === 'function') return '[Function: ' + (val.name || 'anonymous') + ']';
              if (val instanceof Error) return val.name + ': ' + val.message + (val.stack ? '\\n' + val.stack : '');
              if (typeof val === 'object') {
                try { return JSON.stringify(val, null, 2); }
                catch(e) { return Object.prototype.toString.call(val); }
              }
              return String(val);
            }

            self.onmessage = async function(e) {
              const data = e.data || {};
              const code = data.code || '';
              const docmdData = data.docmdData || {};

              const customConsole = {
                log: function(...args) { self.postMessage({ type: 'log', level: 'info', text: args.map(formatVal).join(' ') }); },
                info: function(...args) { self.postMessage({ type: 'log', level: 'info', text: args.map(formatVal).join(' ') }); },
                warn: function(...args) { self.postMessage({ type: 'log', level: 'warn', text: args.map(formatVal).join(' ') }); },
                error: function(...args) { self.postMessage({ type: 'log', level: 'error', text: args.map(formatVal).join(' ') }); },
                table: function(data) {
                  const out = (typeof data === 'object' && data !== null) ? JSON.stringify(data, null, 2) : formatVal(data);
                  self.postMessage({ type: 'log', level: 'info', text: out });
                },
                clear: function() { self.postMessage({ type: 'clear' }); }
              };

              const docmd = {
                version: docmdData.version || '0.10.2',
                var: {
                  _store: docmdData.variables || {},
                  get: function(k) {
                    if (!k || typeof k !== 'string') return undefined;
                    if (k in this._store && this._store[k] !== undefined) return this._store[k];
                    const parts = k.split('.');
                    if (parts.length > 1) {
                      let cur = this._store;
                      let found = true;
                      for (const p of parts) {
                        if (cur !== null && cur !== undefined && typeof cur === 'object' && p in cur) cur = cur[p];
                        else { found = false; break; }
                      }
                      if (found && cur !== undefined) return cur;
                    }
                    if (k === 'docmd.version' || k === 'DOCMD_VERSION' || k === 'version') return docmdData.version;
                    if (k === 'docmd.buildYear' || k === 'BUILD_YEAR') return String(new Date().getFullYear());
                    return undefined;
                  },
                  set: function(k, v) {
                    if (typeof k === 'string') this._store[k] = v;
                    else if (typeof k === 'object' && k !== null) Object.assign(this._store, k);
                  },
                  all: function() { return { ...this._store }; }
                },
                get: function(k) { return this.var.get(k); }
              };

              try {
                const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
                const runner = new AsyncFunction('console', 'docmd', code);
                const result = await runner(customConsole, docmd);
                self.postMessage({ type: 'done', hasReturn: result !== undefined, result: result !== undefined ? formatVal(result) : undefined });
              } catch (err) {
                const errMsg = err?.message || String(err);
                const stack = err?.stack ? String(err.stack).split('\\n').slice(0, 3).join('\\n') : '';
                self.postMessage({ type: 'error', message: errMsg, stack: stack });
              }
            };
          `;

          const blob = new Blob([workerSource], { type: 'application/javascript' });
          const workerUrl = URL.createObjectURL(blob);
          const worker = new Worker(workerUrl);
          this.activeWorker = worker;

          const cleanup = () => {
            if (this.workerTimeout) {
              clearTimeout(this.workerTimeout);
              this.workerTimeout = null;
            }
            if (this.activeWorker === worker) {
              this.activeWorker = null;
            }
            worker.terminate();
            URL.revokeObjectURL(workerUrl);
          };

          // 5000ms safety timeout terminates infinite loops or blocking sync calls
          this.workerTimeout = setTimeout(() => {
            cleanup();
            this.renderErrorNotice('Execution timed out after 5000ms (potential infinite loop terminated).');
            this.appendLog('error', 'TimeoutError: Script execution exceeded 5000ms limit.');
          }, 5000);

          worker.onmessage = (e) => {
            const msg = e.data || {};
            if (msg.type === 'log') {
              this.appendLog(msg.level || 'info', msg.text);
            } else if (msg.type === 'clear') {
              this.clearConsole();
            } else if (msg.type === 'done') {
              if (msg.hasReturn) {
                this.appendLog('return', `=> ${msg.result}`);
              }
              cleanup();
            } else if (msg.type === 'error') {
              this.renderErrorNotice(msg.message);
              this.appendLog('error', `RuntimeError: ${msg.message}`);
              if (msg.stack) {
                this.appendLog('error', msg.stack);
              }
              cleanup();
            }
          };

          worker.onerror = (err) => {
            const msg = err?.message || 'Worker execution error';
            this.renderErrorNotice(msg);
            this.appendLog('error', `WorkerError: ${msg}`);
            cleanup();
          };

          worker.postMessage({ code: cleanJs, docmdData: docmdSnapshot });
          return;
        } catch (workerErr) {
          // Fallback to inline AsyncFunction if Worker/Blob is blocked by strict CSP
        }
      }

      // 2. Fallback AsyncFunction runner (used when Worker is unavailable or blocked by strict CSP)
      try {
        const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
        const runner = new AsyncFunction('console', 'docmd', cleanJs);

        const result = await runner(customConsole, window.docmd || {});
        if (result !== undefined) {
          this.appendLog('return', `=> ${formatValue(result)}`);
        }
      } catch (err) {
        const errMsg = err?.message || String(err);
        this.renderErrorNotice(errMsg);
        this.appendLog('error', `RuntimeError: ${errMsg}`);
        if (err?.stack) {
          const relevantStack = String(err.stack).split('\n').slice(0, 3).join('\n');
          this.appendLog('error', relevantStack);
        }
      }
    }

    renderHtmlPreview(html) {
      if (!this.previewEl) return;
      this.previewEl.innerHTML = '';

      const iframe = document.createElement('iframe');
      iframe.setAttribute('sandbox', 'allow-scripts allow-modals allow-forms');
      iframe.style.width = '100%';
      iframe.style.minHeight = '200px';
      iframe.style.border = 'none';
      iframe.style.background = '#ffffff';
      iframe.style.display = 'block';

      iframe.srcdoc = `<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
      body {
        margin: 0;
        padding: 16px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
        color: #0f172a;
        background: #ffffff;
        box-sizing: border-box;
      }
      * { box-sizing: border-box; }
    </style>
  </head>
  <body>
    ${html}
  </body>
</html>`;

      this.previewEl.appendChild(iframe);
    }

    reset() {
      if (this.activeWorker) {
        this.activeWorker.terminate();
        this.activeWorker = null;
      }
      if (this.workerTimeout) {
        clearTimeout(this.workerTimeout);
        this.workerTimeout = null;
      }
      if (this.editor) {
        this.editor.value = this.initialCode;
      }
      this.clearConsole();
      if (this.previewEl) {
        if (this.lang === 'html' || this.lang === 'xml' || this.lang === 'svg' || this.defaultTab === 'preview') {
          this.renderHtmlPreview(this.initialCode);
        } else {
          this.previewEl.innerHTML = '';
        }
      }
      if (this.container.getAttribute('data-live') === 'true') {
        this.run();
      }
    }

    async copy() {
      if (!this.editor) return;
      const code = this.editor.value;
      try {
        await navigator.clipboard.writeText(code);
        if (this.copyBtn) {
          const origHtml = this.copyBtn.innerHTML;
          this.copyBtn.innerHTML = `
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          `;
          setTimeout(() => {
            if (this.copyBtn) this.copyBtn.innerHTML = origHtml;
          }, 1500);
        }
      } catch {
        // Fallback copy using textarea selection
        this.editor.select();
        document.execCommand('copy');
      }
    }
  }

  function initPlaygrounds() {
    const containers = document.querySelectorAll('.docmd-playground');
    containers.forEach((container) => {
      if (!container.__docmd_playground) {
        container.__docmd_playground = new PlaygroundInstance(container);
      }
    });
  }

  // Auto-init on initial DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPlaygrounds);
  } else {
    initPlaygrounds();
  }

  // Re-hydrate on docmd SPA page navigation events
  document.addEventListener('docmd:page-mounted', initPlaygrounds);
  window.addEventListener('popstate', () => setTimeout(initPlaygrounds, 50));

  // Expose global API
  window.docmd = window.docmd || {};
  const injectedVars = (typeof window !== 'undefined' && window.__DOCMD_VARIABLES__ && typeof window.__DOCMD_VARIABLES__ === 'object') ? window.__DOCMD_VARIABLES__ : {};
  if (!window.docmd.version) {
    window.docmd.version = injectedVars.docmd?.version || injectedVars.DOCMD_VERSION || '0.10.2';
  }
  if (!window.docmd.var) {
    window.docmd.var = {
      _store: {
        docmd: { version: window.docmd.version, buildYear: String(new Date().getFullYear()) },
        version: window.docmd.version,
        DOCMD_VERSION: window.docmd.version,
        ...injectedVars
      },
      get: function(k) {
        if (!k || typeof k !== 'string') return undefined;
        if (k in this._store && this._store[k] !== undefined) return this._store[k];
        const parts = k.split('.');
        if (parts.length > 1) {
          let cur = this._store;
          let found = true;
          for (const p of parts) {
            if (cur !== null && cur !== undefined && typeof cur === 'object' && p in cur) cur = cur[p];
            else { found = false; break; }
          }
          if (found && cur !== undefined) return cur;
        }
        if (k === 'docmd.version' || k === 'DOCMD_VERSION' || k === 'version') return window.docmd.version;
        if (k === 'docmd.buildYear' || k === 'BUILD_YEAR') return String(new Date().getFullYear());
        return undefined;
      },
      set: function(k, v) {
        if (typeof k === 'string') this._store[k] = v;
        else if (typeof k === 'object' && k !== null) Object.assign(this._store, k);
      },
      all: function() { return { ...this._store }; }
    };
  }
  if (!window.docmd.get) {
    window.docmd.get = (k) => window.docmd.var?.get?.(k);
  }
  window.docmd.playground = {
    init: initPlaygrounds
  };
})();